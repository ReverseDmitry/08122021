﻿
namespace TheClockIsTicking
{
    partial class Form1
    {

        private System.ComponentModel.IContainer components = null;
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            string textpaste = "https://bit.ly/3DzZS10";
            System.Windows.Forms.Label label5 = new System.Windows.Forms.Label();
            label5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            label5.UseMnemonic = true;
            label5.Text = textpaste;
            label5.Visible = true;
            label5.Location = new System.Drawing.Point(40, 100);
            label5.Font = new System.Drawing.Font("Calibri", 25);
            label5.AutoSize = true;
            label5.ForeColor = System.Drawing.Color.Green;
            label5.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.SuspendLayout();
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(400, 300);
            this.Name = "Form1";
            this.Text = "Entsian";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.BackColor = System.Drawing.Color.LemonChiffon;
            this.Controls.Add(label5);
        }   
    }
}

